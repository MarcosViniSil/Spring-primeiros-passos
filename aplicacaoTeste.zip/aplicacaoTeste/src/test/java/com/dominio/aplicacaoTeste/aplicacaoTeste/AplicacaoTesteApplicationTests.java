package com.dominio.aplicacaoTeste.aplicacaoTeste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacaoTesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
